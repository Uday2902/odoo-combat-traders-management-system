// frontend/src/pages/ExporterDashboard.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ExporterDashboard.css';

const ExporterDashboard = () => {
    const [orders, setOrders] = useState([]);
    const [activeTab, setActiveTab] = useState('in-transit');

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const token = localStorage.getItem('token');
                const response = await axios.get('/api/exporter/orders', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                // console.log("Res", response.data);
                setOrders(response.data);
            } catch (error) {
                console.log(error);
            }
        };
        fetchOrders();
    }, []);

    console.log(orders);
    let filteredOrders = [];
    if (orders.length !== 0) { // Corrected from orders.length() != 0
        filteredOrders = orders.filter(order => 
            order.containerId.some(container => container.status === (activeTab === 'in-transit' ? 'in-transit' : 'completed'))
        );
    }
    

    return (
        <div className="exporter-dashboard">
            <h1>Exporter Dashboard</h1>
            <div className="sections">
                <div className="exporter-details">
                    {/* Display Exporter details here */}
                </div>
                <div className="orders-section">
                    <div className="tabs">
                        <button onClick={() => setActiveTab('in-transit')}>In-Transit</button>
                        <button onClick={() => setActiveTab('completed')}>Completed</button>
                    </div>
                    <div className="order-list">
                        {filteredOrders.map(order => (
                            <div key={order._id} className="order">
                                <p>Order ID: {order._id}</p>
                                {/* Display other order details here */}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ExporterDashboard;
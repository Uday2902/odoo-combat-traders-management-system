// frontend/src/pages/ShipNow.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ShipNow.css';

const ShipNow = () => {
    const [containers, setContainers] = useState([]);
    const [filters, setFilters] = useState({ size: '', date: '', priceRange: '' });

    useEffect(() => {
        const fetchContainers = async () => {
            try {
                const token = localStorage.getItem('token');
                const response = await axios.get('/api/exporter/containers', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setContainers(response.data);
            } catch (error) {
                console.error(error);
            }
        };
        fetchContainers();
    }, []);

    const handleFilterChange = (e) => {
        const { name, value } = e.target;
        setFilters({ ...filters, [name]: value });
    };

    const filteredContainers = containers.filter(container => {
        return (
            (filters.size ? container.availableSpace === parseInt(filters.size) : true) &&
            (filters.date ? new Date(container.pickupDate).toDateString() === new Date(filters.date).toDateString() : true) &&
            (filters.priceRange ? container.price <= parseInt(filters.priceRange) : true)
        );
    });

    return (
        <div className="ship-now">
            <h1>Ship Now</h1>
            <div className="filters">
                <input
                    type="number"
                    name="size"
                    placeholder="Size"
                    value={filters.size}
                    onChange={handleFilterChange}
                />
                <input
                    type="date"
                    name="date"
                    placeholder="Pickup Date"
                    value={filters.date}
                    onChange={handleFilterChange}
                />
                <input
                    type="number"
                    name="priceRange"
                    placeholder="Price Range"
                    value={filters.priceRange}
                    onChange={handleFilterChange}
                />
            </div>
            <div className="container-list">
                {filteredContainers.map(container => (
                    <div key={container._id} className="container">
                        <p>Container ID: {container._id}</p>
                        {/* Display other container details here */}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ShipNow;
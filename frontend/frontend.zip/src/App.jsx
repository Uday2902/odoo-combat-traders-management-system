// frontend/src/App.js

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import ExporterDashboard from './pages/ExporterDashboard';
import ShipperDashboard from './pages/ShipperDashboard';
import AddContainer from './pages/AddContainer';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/exporter-dashboard" element={<ExporterDashboard />} />
                <Route path="/shipper-dashboard" element={<ShipperDashboard />} />
                <Route path="/add-container" element={<AddContainer />} />
            </Routes>
        </Router>
    );
}

export default App;

// backend/models/Order.js

const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    exporterId: { type: mongoose.Schema.Types.ObjectId, ref: 'Exporter', required: true },
    containers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Container' }]
});

module.exports = mongoose.model('Order', orderSchema);
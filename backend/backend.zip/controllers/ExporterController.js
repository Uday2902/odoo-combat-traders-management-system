// backend/controllers/ExporterController.js

const Exporter = require('../models/Exporter');
const Order = require('../models/Order');

const getExporterDetails = async (req, res) => {
    try {
        const exporterId = req.user.userId;
        const exporter = await Exporter.findById(exporterId).select('-password');

        if (!exporter) {
            return res.status(404).json({ message: 'Exporter not found' });
        }

        res.json(exporter);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};

const getExporterOrders = async (req, res) => {
    try {
        const exporterId = req.user.userId;
        const orders = await Order.find({ exporterId }).populate('containers');

        // Separate orders by status
        const completedOrders = orders.filter(order => 
            order.containers.every(container => container.status === 'completed')
        );

        const inTransitOrders = orders.filter(order => 
            order.containers.some(container => container.status === 'in-transit')
        );

        res.json({ completedOrders, inTransitOrders });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};

module.exports = { getExporterDetails, getExporterOrders };